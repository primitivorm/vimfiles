module Foo
  class Bar
    f do
      g { def h; end }
    end

    if foo
      bar ; end

    if bar ; end

    foo do
      foo = 3 . class
      foo = lambda { class One; end }
      foo = lambda { |args| class One; end }
      foo = bar; class One; end
    end
  end
end
