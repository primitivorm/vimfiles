# vim-tomdoc

Some helper functions to add TomDoc templates to your Ruby code.

* TomDocMethod() — mapped to normal tdm
* TomDocClass() — mapped to normal tdc
* TomDocModule() — mapped to normal tdmo
* TomDocConstant() — mapped to normal tdco
* TomDocAttrReader() — mapped to normal tdar
* TomDocAttrWriter() — mapped to normal tdaw
* TomDocAttrAccessor() — mapped to normal tdaa
