﻿namespace OmniSharp.Rename
{
    public class ModifiedFileResponse
    {
        public string FileName { get; set; }
        public string Buffer { get; set; }
    }
}