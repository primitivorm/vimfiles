﻿using OmniSharp.Common;

namespace OmniSharp.GotoDefinition
{
    public class GotoDefinitionRequest : Request
    {
    }
}