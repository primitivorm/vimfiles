## Known issues
* Shorthand customization of keys not implemented yet.

## NEXT
* repeat last seek with ; and ,

## 0.7 - 2013-03-10
* offer ignore case seek option and custom char aliases.
* handle multi-byte string seeks correctly.

## 0.5 - 2013-01-30
* allow key customization of all seek motions.
* implement remote jump motions.

## 0.2 - 2013-01-27
* remap operator pending keys due to conflicts.

## 0.1 - 2013-01-26
* initial release.
