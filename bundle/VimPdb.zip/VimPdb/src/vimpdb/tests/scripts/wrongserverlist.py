print "WRONG"
