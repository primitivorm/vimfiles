class BadRCFile(Exception):
    pass


class ReturnCodeError(Exception):
    pass


class BrokenConfiguration(Exception):
    pass


class RemoteUnavailable(Exception):
    pass
