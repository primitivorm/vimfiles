OmniSharpServer
===============

HTTP wrapper around NRefactory allowing C# editor plugins to be written for any editor in any language.


This is the server component for the [Vim OmniSharp plugin](https://github.com/nosami/OmniSharp) and [Sublime OmniSharp plugin](https://github.com/PaulCampbell/OmniSharpSublimePlugin)
