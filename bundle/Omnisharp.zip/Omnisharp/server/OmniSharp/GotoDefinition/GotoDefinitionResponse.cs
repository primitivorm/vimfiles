﻿namespace OmniSharp.GotoDefinition
{
    public class GotoDefinitionResponse
    {
        public string FileName;
        public int Line;
        public int Column;
    }
}