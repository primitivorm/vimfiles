﻿namespace OmniSharp.ProjectManipulation.AddReference
{
    public class AddReferenceResponse
    {
        public string Message { get; set; }
    }
}