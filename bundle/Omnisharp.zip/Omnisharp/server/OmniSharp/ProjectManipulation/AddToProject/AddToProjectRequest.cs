﻿using OmniSharp.Common;

namespace OmniSharp.ProjectManipulation.AddToProject
{
    public class AddToProjectRequest : Request
    {
    }
}
