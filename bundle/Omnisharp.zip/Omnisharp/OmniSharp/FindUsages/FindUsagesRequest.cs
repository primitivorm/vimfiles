﻿using OmniSharp.Common;

namespace OmniSharp.FindUsages
{
    public class FindUsagesRequest : Request
    {
    }
}