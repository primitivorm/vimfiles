﻿using OmniSharp.Common;

namespace OmniSharp.TypeLookup
{
    public class TypeLookupRequest : Request
    {
    }
}
