﻿using OmniSharp.Common;

namespace OmniSharp.AutoComplete
{
    public class AutoCompleteRequest : Request
    {
        public string WordToComplete { get; set; }
    }
}
