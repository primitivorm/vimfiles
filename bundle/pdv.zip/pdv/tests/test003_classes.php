<?php

class SimplestClass {
}

class DerivedClass extends BaseClass
{
}

class ImplementingClass implements InterfaceA, InterfaceB
{
}

    abstract class AbstractClass {
    }

final class FinalClass
{
}


abstract class AllTogether extends ABaseClass implements InterfaceA {
}

  class             FancyFormat      extends FancyWhitespace            {
  }
