#!/bin/sh

. ./test.bat
