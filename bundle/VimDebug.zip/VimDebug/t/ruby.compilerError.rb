#!ruby

sub oogetyboogety {
