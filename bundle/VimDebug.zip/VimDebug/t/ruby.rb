#!/usr/bin/ruby


def foo()
   monkeyman = "fantasy pants"
   deaf = "mute"
   deaf = "mute"
   deaf = "mute"
end

monkey = "a"
goat = 1
dog  = 2
sic = 'adsf', 'lkj', 'qwe'

foo()

boy = goat + dog
boy = goat + dog
boy = goat + dog
boy = goat + dog
