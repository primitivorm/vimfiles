#!perl

sub oogetyboogety {
