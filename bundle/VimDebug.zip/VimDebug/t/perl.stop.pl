#!perl


sub foo {
   my $foo = "monkey";
   my $a = 0;
   my $b = 4;
   my $c = $a + $b;
}

my $a = 1;
my $b = 2;
my $c = $a + $b;
my $d = 7;

foo();

my $monkey  = "i want bananas";
my $gorilla = "i want bananas";
my $chimp   = "i want bananas";
my $human   = "i want bananas";

while (1) {
   sleep 1;
}


