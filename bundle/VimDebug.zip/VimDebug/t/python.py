#!/usr/bin/python



def foo():
   foo = "monkey";
   a = 0;
   b = 4;
   return 73;

a = 1;
b = 2;
c = a + b;
d = 7;

foo();

monkey  = "i want bananas";
gorilla = "i want bananas";
chimp   = "i want bananas";
human   = "i want bananas";

