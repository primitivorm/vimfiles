Please visit the `project homepage`_ or `Vim Online`_ for more information.

.. _project homepage: http://www.topbug.net/SingleCompile
.. _Vim Online: http://www.vim.org/scripts/script.php?script_id=3115
