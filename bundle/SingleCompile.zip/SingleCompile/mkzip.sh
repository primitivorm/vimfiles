#!/bin/sh

zip SingleCompile.zip autoload/*.vim autoload/SingleCompile/templates/*.vim plugin/*.vim doc/*.txt
