﻿#region Using directives

using System;
using System.Reflection;
using System.Runtime.InteropServices;

#endregion

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyCompany("ICSharpCode")]
[assembly: AssemblyProduct("SharpDevelop/MonoDevelop")]
[assembly: AssemblyCopyright("Copyright 2010-2013 AlphaSierraPapa")]

// This sets the default COM visibility of types in the assembly to invisible.
// If you need to expose a type to COM, use [ComVisible(true)] on that type.
[assembly: ComVisible(false)]

// We keep the AssemblyVersion at 5.0.0.0 for all versions of NRefactory 5.
// This eliminates the need for binding redirects.
[assembly: AssemblyVersion("5.0.0.0")]

// [AssemblyFileVersion] is the version of the NuGet package,
// should follow http://semver.org/ rules
[assembly: AssemblyFileVersion("5.3.0")]
