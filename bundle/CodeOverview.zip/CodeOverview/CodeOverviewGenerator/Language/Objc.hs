-- | Module for an objective C highlighter, currently unimplemented.
module CodeOverviewGenerator.Language.Objc where

import CodeOverviewGenerator.Language
import CodeOverviewGenerator.Language.C

