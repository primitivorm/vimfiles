-- | Module used to provide a single bytestring across the project,
-- and be able to change it later.
module CodeOverviewGenerator.ByteString ( module Data.ByteString.Char8 ) where

import Data.ByteString.Char8

