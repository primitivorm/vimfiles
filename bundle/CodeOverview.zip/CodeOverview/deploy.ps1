$VIMDIR = "$HOME/vimfiles";

cp CodeOverview/plugin/CodeOverview.vim "$VIMDIR/bundle/vim-codeoverview/plugin/CodeOverview.vim"
cp CodeOverview/syntax/codeoverview.vim "$VIMDIR/bundle/vim-codeoverview/syntax/codeoverview.vim"
cp CodeOverview/ftdetect/codeoverview.vim "$VIMDIR/bundle/vim-codeoverview/ftdetect/codeoverview.vim"
