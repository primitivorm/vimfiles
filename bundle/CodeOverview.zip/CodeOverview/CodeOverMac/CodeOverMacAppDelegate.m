//
//  CodeOverMacAppDelegate.m
//  CodeOverMac
//
//  Created by Vincent Berthoux on 05/04/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "CodeOverMacAppDelegate.h"



@implementation CodeOverMacAppDelegate
@synthesize window;
@synthesize watcher;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application 
}

@end
