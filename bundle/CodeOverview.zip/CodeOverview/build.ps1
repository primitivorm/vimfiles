ghc --make -O2 -Wall -o "$HOME/dotfiles/vimfiles/bundle/vim-codeoverview/plugin/codeoverview.exe" codeOverviewMain.hs

