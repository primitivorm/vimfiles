describe "something"
  it "does something" do
    "something".should eq "something else"
  end
end
