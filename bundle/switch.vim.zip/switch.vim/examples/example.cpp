int main(int argc, const char *args[]) {
	Object* foo = bar->baz->bla;

	return 0;
}
