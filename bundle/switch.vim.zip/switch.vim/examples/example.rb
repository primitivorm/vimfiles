if something || something_else
  do_something(:flag => true)

  foo = {
    :bar => 'baz', :bla => 'bla'
  }

  bar = user.comments.map(&:author).name

  baz = "foo"

  ['one', 'two', 'three']
end
