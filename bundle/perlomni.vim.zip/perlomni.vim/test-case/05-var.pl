
my %hash = ( );
my @array = ( );

%
@


# complete variable
$var1 $var2 $var3 $var_test $var__adfasdf
$var__adfasd  $var1  $var_
$test  $test  $zzz
$zzz
