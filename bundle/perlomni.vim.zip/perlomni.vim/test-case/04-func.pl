
# complete built-in function
seekdir splice 



