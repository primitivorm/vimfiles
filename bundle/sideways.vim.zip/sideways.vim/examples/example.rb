# TODO Not working yet

link_to 'Something', user_registration_path

if (one and two) or three
  three
end
