def function(three, one, two):
    pass

def function(one, [1, 2, 3], two):
    pass

def function(one, three, two
    pass

list = [[four, two, five], three, one]

list = ['foo', 'baz', 'bar']

foo(bar, baz(foobar(), foobaz))

foo([ 'baz', 'quux', 'bar' ])
