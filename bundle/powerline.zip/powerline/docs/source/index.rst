*********
Powerline
*********

.. toctree::
   :maxdepth: 2
   :glob:

   introduction
   overview
   configuration
   tipstricks
   fontpatching
   license-credits

Segments
========

.. toctree::
   segments/common
   segments/shell
   segments/vim

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
