<?php

namespace ${1:`!v PathToNamespace(expand("%:h"))`};

class ${2:`!v expand("%:t:r")`}
{
    ${3}
}
