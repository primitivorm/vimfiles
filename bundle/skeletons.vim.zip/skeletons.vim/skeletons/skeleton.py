#!/usr/bin/python
#coding : utf-8
#file : <+FILE_NAME+>
#author : ning
#date : <+DATE+>

def main():
"""docstring for main"""
pass

if __name__ == "__main__":
main()

