# ======================================================================================
# File         : settings_unix.py
# Author       : Wu Jie 
# Last Change  : 01/05/2011 | 16:44:53 PM | Wednesday,January
# Description  : 
# ======================================================================================

#/////////////////////////////////////////////////////////////////////////////
# global variables
#/////////////////////////////////////////////////////////////////////////////

version = "8.05_b2"
patched_plugins_version = "2.2"
target_path = "/Users/Johnny/dev/release/exvim"
build_path = target_path + "/src"
exvim_path = "/Users/Johnny/exdev/exvim"
exenv_path = "/Users/Johnny/exdev/exenv"
graphviz_path = "/Users/Johnny/tools/Graphviz"
irfanview_path = "/Users/Johnny/tools/IrfanView"
