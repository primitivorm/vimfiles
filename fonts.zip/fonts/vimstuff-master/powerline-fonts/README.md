vim-powerline-fonts
===================

Vim Powerline Patched Fonts. 

All of these fonts are freely available on the web, so there should be no licensing concerns.

If you have a font you'd like patched, let me know. If I have time, I will do it for you...though if you are reading this it is quite likely you already know how to do that!
