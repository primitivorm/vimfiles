powerline-segments
==================

Segments to add to Vim Powerline status bar

TabWarn
-------

Adds a segment to the status bar that warns you if you have a mix of tab types (tabs using spaces and actual tab characters)

