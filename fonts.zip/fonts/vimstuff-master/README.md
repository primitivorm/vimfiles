vimstuff
========

Various bits and pieces that work with Vim