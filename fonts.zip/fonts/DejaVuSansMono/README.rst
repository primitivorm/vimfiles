DejaVuSansMono for Powerline
============================

:Font creator: Roy Y.T. Chen
:Source: http://dejavu-fonts.org/wiki/Main_Page
:Patched by: `Cyt <https://github.com/cyt>`

