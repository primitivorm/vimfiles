Menlo for Powerline
===================

:Font creator: Jim Lyles
:Source: Provided by system
:Patched by: `oschrenk <https://github.com/oschrenk>`_
